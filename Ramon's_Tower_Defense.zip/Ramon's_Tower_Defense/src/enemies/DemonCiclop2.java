package enemies;


import managers.EnemyManager;
import static auxiliar.Constants.Enemies.DemonCiclop2;

public class DemonCiclop2 extends Enemy {

	public DemonCiclop2(float x, float y, int ID, EnemyManager em) {
		super(x, y, ID, DemonCiclop2,em);
	}

}
