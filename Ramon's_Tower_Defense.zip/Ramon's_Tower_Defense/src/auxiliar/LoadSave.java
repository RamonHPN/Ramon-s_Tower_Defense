// Define o pacote 'helpz' para organização do código
// Encapsulamento
// Abstração
package auxiliar;

// Importa classes necessárias da biblioteca padrão Java
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;

// Declaração da classe utilitária 'LoadSave'
public class LoadSave {

    // Método para obter uma imagem do sprite atlas principal
    //Cada método getSpriteAtlasX age como um Factory Method, fornecendo uma 
    //maneira de criar e retornar instâncias de BufferedImage com base no caminho do recurso. 
    public static BufferedImage getSpriteAtlas() {
        BufferedImage img = null;
        // Obtém um fluxo de entrada para o arquivo de imagem do sprite atlas principal
        InputStream is = LoadSave.class.getResourceAsStream("/resources/spriteatlas.png");

        try {
            // Lê a imagem do fluxo de entrada
            img = ImageIO.read(is);
        } catch (IOException e) {
            // Em caso de erro ao ler a imagem, imprime a exceção
            e.printStackTrace();
        }
        // Retorna a imagem lida
        return img;
    }

    // Métodos para obter imagens de outros recursos específicos
    // Cada método segue uma estrutura semelhante
        public static BufferedImage getSpriteAtlas2() {
		BufferedImage img = null;
		InputStream is2 = LoadSave.class.getResourceAsStream("/resources/DemonCyclop/Idle.png");

		try {
			img = ImageIO.read(is2);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}
        public static BufferedImage getSpriteAtlas3() {
		BufferedImage img = null;
		InputStream is3 = LoadSave.class.getResourceAsStream("/resources/GiantFlam/Idle.png");

		try {
			img = ImageIO.read(is3);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}
        public static BufferedImage getSpriteAtlas4() {
		BufferedImage img = null;
		InputStream is3 = LoadSave.class.getResourceAsStream("/resources/GiantSpirit/Idle.png");

		try {
			img = ImageIO.read(is3);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}
        public static BufferedImage getSpriteAtlas5() {
		BufferedImage img = null;
		InputStream is3 = LoadSave.class.getResourceAsStream("/resources/DemonCyclop2/Idle.png");

		try {
			img = ImageIO.read(is3);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}
        public static BufferedImage getSpriteAtlas6() {
		BufferedImage img = null;
		InputStream is3 = LoadSave.class.getResourceAsStream("/resources/DoubleHouse-removebg-preview.png");

		try {
			img = ImageIO.read(is3);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}
        
        public static BufferedImage getSpriteAtlas7() {
		BufferedImage img = null;
		InputStream is3 = LoadSave.class.getResourceAsStream("/resources/mod/TowerWood.png");

		try {
			img = ImageIO.read(is3);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}
        public static BufferedImage getSpriteAtlas8() {
		BufferedImage img = null;
		InputStream is3 = LoadSave.class.getResourceAsStream("/resources/mod/house1__1_-removebg-preview.png");

		try {
			img = ImageIO.read(is3);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}
        
        public static BufferedImage getSpriteAtlas9() {
		BufferedImage img = null;
		InputStream is3 = LoadSave.class.getResourceAsStream("/resources/mod/house2 (1).png");

		try {
			img = ImageIO.read(is3);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}
        public static BufferedImage getSpriteAtlas10() {
		BufferedImage img = null;
		InputStream is3 = LoadSave.class.getResourceAsStream("/resources/mod/houseOca.png");

		try {
			img = ImageIO.read(is3);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}
        
        
}
