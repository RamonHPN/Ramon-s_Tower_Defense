package scenes;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import enemies.Enemy;
import main.Game;
import managers.EnemyManager;
import managers.ProjectileManager;
import managers.TowerManager;
import managers.WaveManager;
import objects.PathPoint;
import objects.Tower;
import ui.ActionBar;
import static auxiliar.Constants.Tiles.GRASS_TILE;
import auxiliar.LevelBuild;

// A classe Playing representa a cena do jogo onde o jogador interage
public class Playing extends GameScene implements SceneMethods {

    // Representação do layout do nível em uma matriz
    private int[][] lvl;

    // Barra de ação no jogo
    private ActionBar actionBar;

    // Posição atual do mouse
    private int mouseX, mouseY;

    // Gerenciadores do jogo
    private EnemyManager enemyManager;
    private TowerManager towerManager;
    private ProjectileManager projManager;
    private WaveManager waveManager;

    // Pontos de início e fim do caminho para os inimigos
    private PathPoint start, end;

    // Torre atualmente selecionada pelo jogador
    private Tower selectedTower;

    // Contador para gerenciar a geração de ouro
    private int goldTick;

    // Flag indicando se o jogo está pausado
    private boolean gamePaused;

    // Construtor da classe Playing
    public Playing(Game game) {
        // Chamando o construtor da superclasse GameScene
        super(game);
        // Carregando o layout padrão do nível
        loadDefaultLevel();

        // Inicializando a barra de ação e os gerenciadores do jogo
        actionBar = new ActionBar(0, 640, 896 + 128 + 128, 160, this);
        enemyManager = new EnemyManager(this, start, end);
        towerManager = new TowerManager(this);
        projManager = new ProjectileManager(this);
        waveManager = new WaveManager(this);
    }

    // Método para carregar o layout padrão do nível
    private void loadDefaultLevel() {
        lvl = LevelBuild.getLevelData();
        start = new PathPoint(0, 19); // Define as coordenadas de início do caminho.
        end = new PathPoint(26, 15);
    }

    // Método para definir uma matriz de nível personalizada
    public void setLevel(int[][] lvl) {
        this.lvl = lvl;
    }

	public void update() {
		// Verifica se o jogo não está pausado
		if (!gamePaused) {
			updateTick(); // Atualiza o contador de ticks
			waveManager.update(); // Atualiza o gerenciador de ondas

			// Controle de geração de ouro a cada intervalo de tempo
			goldTick++;
			if (goldTick % (60 * 3) == 0)
				actionBar.addGold(3);

			// Verifica se todos os inimigos foram derrotados
			if (isAllEnemiesDead()) {
				if (isThereMoreWaves()) {
					waveManager.startWaveTimer(); // Inicia o temporizador de onda
					if (isWaveTimerOver()) {
						waveManager.increaseWaveIndex(); // Incrementa o índice da onda
						enemyManager.getEnemies().clear(); // Limpa a lista de inimigos
						waveManager.resetEnemyIndex(); // Reinicia o índice de inimigos

					}
				}
			}

			// Verifica se é hora de gerar um novo inimigo
			if (isTimeForNewEnemy()) {
				if (!waveManager.isWaveTimerOver())
					spawnEnemy(); // Gera um novo inimigo
			}

			enemyManager.update(); // Atualiza o gerenciador de inimigos
			towerManager.update(); // Atualiza o gerenciador de torres
			projManager.update(); // Atualiza o gerenciador de projéteis
		}
	}

	// Verifica se o temporizador de onda chegou ao fim
	private boolean isWaveTimerOver() {
		return waveManager.isWaveTimerOver();
	}

	// Verifica se há mais ondas a serem geradas
	private boolean isThereMoreWaves() {
		return waveManager.isThereMoreWaves();
	}

	// Verifica se todos os inimigos foram derrotados
	private boolean isAllEnemiesDead() {
		if (waveManager.isThereMoreEnemiesInWave())
			return false;

		for (Enemy e : enemyManager.getEnemies())
			if (e.isAlive())
				return false;

		return true;
	}

	// Gera um novo inimigo
	private void spawnEnemy() {
		enemyManager.spawnEnemy(waveManager.getNextEnemy());
	}

	// Verifica se é hora de gerar um novo inimigo
	private boolean isTimeForNewEnemy() {
		if (waveManager.isTimeForNewEnemy()) {
			if (waveManager.isThereMoreEnemiesInWave())
				return true;
		}

		return false;
	}

	// Define a torre selecionada pelo jogador
	public void setSelectedTower(Tower selectedTower) {
		this.selectedTower = selectedTower;
	}

	@Override
	public void render(Graphics g) {
		// Renderiza os elementos do jogo
		drawLevel(g);
		actionBar.draw(g);
		enemyManager.draw(g);
		towerManager.draw(g);
		projManager.draw(g);

		drawSelectedTower(g);
		drawHighlight(g);

	}

	// Desenha um destaque na posição do mouse
	private void drawHighlight(Graphics g) {
		g.setColor(Color.WHITE);
		g.drawRect(mouseX, mouseY, 32, 32);
	}

	// Desenha a torre selecionada na posição do mouse
	private void drawSelectedTower(Graphics g) {
		if (selectedTower != null)
			g.drawImage(towerManager.getTowerImgs()[selectedTower.getTowerType()], mouseX, mouseY, null);
	}

	// Desenha o layout do nível
	private void drawLevel(Graphics g) {
		for (int y = 0; y < lvl.length; y++) {
			for (int x = 0; x < lvl[y].length; x++) {
				int id = lvl[y][x];
				if (isAnimation(id)) {
					g.drawImage(getSprite(id, animationIndex), x * 32, y * 32, null);
				} else
					g.drawImage(getSprite(id), x * 32, y * 32, null);
			}
		}
	}

	// Obtém o tipo de bloco em uma posição específica do mouse
	public int getTileType(int x, int y) {
		int xCord = x / 32;
		int yCord = y / 32;

		if (xCord < 0 || xCord > 35)
			return 0;
		if (yCord < 0 || yCord > 19)
			return 0;

		int id = lvl[y / 32][x / 32];
		return game.getTileManager().getTile(id).getTileType();
	}

	// Manipula o evento de clique do mouse
	@Override
	public void mouseClicked(int x, int y) {
		// Abaixo de 640y (região da barra de ação)
		if (y >= 640)
			actionBar.mouseClicked(x, y);
		else {
			// Acima de 640y
			if (selectedTower != null) {
				// Tentando colocar uma torre
				if (isTileGrass(mouseX, mouseY)) {
					if (getTowerAt(mouseX, mouseY) == null) {
						towerManager.addTower(selectedTower, mouseX, mouseY);

						removeGold(selectedTower.getTowerType());

						selectedTower = null;

					}
				}
			} else {
				// Não tentando colocar uma torre
				// Verifica se existe uma torre em x, y
				Tower t = getTowerAt(mouseX, mouseY);
				actionBar.displayTower(t);
			}
		}
	}
        
        // Remove ouro ao construir uma torre
	private void removeGold(int towerType) {
		actionBar.payForTower(towerType);
	}

	// Obtém a torre em uma posição específica do mouse
	private Tower getTowerAt(int x, int y) {
		return towerManager.getTowerAt(x, y);
	}

	// Verifica se o bloco em uma posição específica é grama
	private boolean isTileGrass(int x, int y) {
		int id = lvl[y / 32][x / 32];
		int tileType = game.getTileManager().getTile(id).getTileType();
		return tileType == GRASS_TILE;
	}

	// Inicia o disparo de um projétil de uma torre para um inimigo
	public void shootEnemy(Tower t, Enemy e) {
		projManager.newProjectile(t, e);
	}

	// Define se o jogo está pausado
	public void setGamePaused(boolean gamePaused) {
		this.gamePaused = gamePaused;
	}

	// Manipula o evento de tecla pressionada
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
			selectedTower = null;
		}
	}

	// Manipula o evento de movimento do mouse
	@Override
	public void mouseMoved(int x, int y) {
		if (y >= 640)
			actionBar.mouseMoved(x, y);
		else {
			mouseX = (x / 32) * 32;
			mouseY = (y / 32) * 32;
		}
	}

	// Manipula o evento de clique do mouse
	@Override
	public void mousePressed(int x, int y) {
		if (y >= 640)
			actionBar.mousePressed(x, y);
	}

	// Manipula o evento de liberação do clique do mouse
	@Override
	public void mouseReleased(int x, int y) {
		actionBar.mouseReleased(x, y);
	}

	// Manipula o evento de movimento arrastado do mouse
	@Override
	public void mouseDragged(int x, int y) {
		// TODO Auto-generated method stub
	}

	// Recompensa o jogador ao derrotar um inimigo
	public void rewardPlayer(int enemyType) {
		actionBar.addGold(auxiliar.Constants.Enemies.GetReward(enemyType));
	}

	// Obtém o gerenciador de torres
	public TowerManager getTowerManager() {
		return towerManager;
	}

	// Obtém o gerenciador de inimigos
	public EnemyManager getEnemyManger() {
		return enemyManager;
	}

	// Obtém o gerenciador de ondas
	public WaveManager getWaveManager() {
		return waveManager;
	}

	// Verifica se o jogo está pausado
	public boolean isGamePaused() {
		return gamePaused;
	}

	// Remove uma vida do jogador
	public void removeOneLife() {
		actionBar.removeOneLife();
	}

	// Reseta todos os elementos do jogo
	public void resetEverything() {
		actionBar.resetEverything();

		// Reseta os gerenciadores
		enemyManager.reset();
		towerManager.reset();
		projManager.reset();
		waveManager.reset();

		// Reseta variáveis de controle
		mouseX = 0;
		mouseY = 0;
		selectedTower = null;
		goldTick = 0;
		gamePaused = false;
	}
}
//A classe Playing estende GameScene, indicando um relacionamento de herança.
//A classe Playing compõe instâncias de várias outras classes, como ActionBar, 
//EnemyManager, TowerManager, ProjectileManager, WaveManager. Isso segue o princípio de composição.