package objects;

// Classe que representa uma torre no jogo
public class Tower {

    // Posição da torre
    private int x, y;

    // Identificador único da torre
    private int id;

    // Tipo da torre (usando constantes definidas em helpz.Constants.Towers)
    private int towerType;

    // Contador de ticks para controle de cooldown
    private int cdTick;

    // Dano causado pela torre
    private int dmg;

    // Alcance da torre
    private float range;

    // Tempo de recarga da torre
    private float cooldown;

    // Nível (tier) da torre
    private int tier;

    // Construtor da classe Tower
    public Tower(int x, int y, int id, int towerType) {
        // Inicializa os atributos básicos da torre
        this.x = x;
        this.y = y;
        this.id = id;
        this.towerType = towerType;
        System.out.println("toweeeeeeeeeeeee" + towerType);
        
        // Define o nível inicial da torre como 1
        tier = 1;

        // Configura os valores padrão para dano, alcance e tempo de recarga
        setDefaultDmg();
        setDefaultRange();
        setDefaultCooldown();
    }

    // Método chamado regularmente para atualizar o estado da torre
    public void update() {
        // Incrementa o contador de ticks
        cdTick++;
    }

    // Método para verificar se o tempo de recarga da torre acabou
    public boolean isCooldownOver() {
        return cdTick >= cooldown;
    }

    // Reinicia o contador de tempo de recarga
    public void resetCooldown() {
        cdTick = 0;
    }

    // Configura o tempo de recarga padrão com base no tipo de torre
    private void setDefaultCooldown() {
        cooldown = auxiliar.Constants.Towers.GetDefaultCooldown(towerType);
    }

    // Configura o alcance padrão com base no tipo de torre
    private void setDefaultRange() {
        range = auxiliar.Constants.Towers.GetDefaultRange(towerType);
    }

    // Configura o dano padrão com base no tipo de torre
    private void setDefaultDmg() {
        dmg = auxiliar.Constants.Towers.GetStartDmg(towerType);
    }

    // Métodos Getter para obter valores específicos da torre

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTowerType() {
        return towerType;
    }

    public void setTowerType(int towerType) {
        this.towerType = towerType;
    }

    public int getDmg() {
        return dmg;
    }

    public float getRange() {
        return range;
    }

    public float getCooldown() {
        return cooldown;
    }

    public int getTier() {
        return tier;
    }
}

