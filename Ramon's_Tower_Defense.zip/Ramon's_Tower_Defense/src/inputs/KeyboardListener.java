// Define o pacote 'inputs' para organização do código
package inputs;

// Importa classes necessárias da biblioteca padrão Java e classes do projeto 'main'
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import static main.GameStates.*;
import main.Game;
import main.GameStates;

// Declaração da classe 'KeyboardListener' que implementa a interface 'KeyListener'
public class KeyboardListener implements KeyListener {
    private Game game;

    // Construtor que recebe uma instância da classe 'Game'
    public KeyboardListener(Game game) {
        this.game = game;
    }

    // Método chamado quando uma tecla é digitada
    @Override
    public void keyTyped(KeyEvent e) {
        // TODO Auto-generated method stub
    }

    // Método chamado quando uma tecla é pressionada
    @Override
    public void keyPressed(KeyEvent e) {
        // Verifica o estado do jogo para determinar qual método chamar
        if (GameStates.gameState == PLAYING)
            game.getPlaying().keyPressed(e);
    }

    // Método chamado quando uma tecla é liberada
    @Override
    public void keyReleased(KeyEvent e) {
        // TODO Auto-generated method stub
    }
}
