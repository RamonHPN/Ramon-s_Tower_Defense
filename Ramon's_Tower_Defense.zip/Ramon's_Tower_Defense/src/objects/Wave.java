package objects;

// Importa a classe ArrayList da biblioteca padrão Java
import java.util.ArrayList;

// Declaração da classe 'Wave'
public class Wave {
    // Atributo privado para armazenar a lista de inimigos na onda
    private ArrayList<Integer> enemyList;

    // Construtor da classe 'Wave', recebe uma lista de inimigos como parâmetro
    public Wave(ArrayList<Integer> enemyList) {
        // Inicializa o atributo 'enemyList' com a lista fornecida
        this.enemyList = enemyList;
    }

    // Método getter para obter a lista de inimigos da onda
    public ArrayList<Integer> getEnemyList() {
        return enemyList;
    }
}