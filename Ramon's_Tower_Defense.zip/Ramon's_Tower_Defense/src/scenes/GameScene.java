package scenes;

import java.awt.image.BufferedImage;

import main.Game;

// Classe base para todas as cenas do jogo
public class GameScene {

    // Referência para a instância do jogo
    protected Game game;

    // Índice de animação atual
    protected int animationIndex;

    // Velocidade de animação (número de ticks antes de avançar para o próximo frame)
    protected int ANIMATION_SPEED = 25;

    // Contador de ticks
    protected int tick;

    // Construtor que recebe uma instância do jogo
    public GameScene(Game game) {
        this.game = game;
    }

    // Método para obter a instância do jogo
    public Game getGame() {
        return game;
    }

    // Verifica se um sprite possui animação com base no ID do sprite
    protected boolean isAnimation(int spriteID) {
        return game.getTileManager().isSpriteAnimation(spriteID);
    }

    // Atualiza o contador de ticks e o índice de animação
    protected void updateTick() {
        tick++;
        if (tick >= ANIMATION_SPEED) {
            tick = 0;
            animationIndex++;
            if (animationIndex >= 4)
                animationIndex = 0;
        }
    }

    // Obtém um sprite com base no ID do sprite
    protected BufferedImage getSprite(int spriteID) {
        return game.getTileManager().getSprite(spriteID);
    }

    // Obtém um sprite de animação com base no ID do sprite e no índice de animação
    protected BufferedImage getSprite(int spriteID, int animationIndex) {
        return game.getTileManager().getAniSprite(spriteID, animationIndex);
    }

}
//A classe GameScene é uma classe base que é estendida por outras classes, 
//como GameOver e Playing. Isso segue o princípio de herança na programação orientada a objetos.