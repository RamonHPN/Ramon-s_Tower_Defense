package managers;

import java.awt.Color;
import java.awt.Graphics;

import java.awt.image.BufferedImage;
import java.util.ArrayList;

import enemies.GiantFlam;
import enemies.Enemy;
import enemies.GiantSpirit;
import enemies.DemonCiclop2;
import enemies.DemonCiclop;
import auxiliar.LoadSave;
import objects.PathPoint;
import scenes.Playing;
import static auxiliar.Constants.Direction.*;
import static auxiliar.Constants.Tiles.*;
import static auxiliar.Constants.Enemies.*;

public class EnemyManager {

	private Playing playing;
	private BufferedImage[] enemyImgs;
	private ArrayList<Enemy> enemies = new ArrayList<>();
	private PathPoint start, end;
	private int HPbarWidth = 20;
	private BufferedImage slowEffect;
        
        //Aqui, está definindo a classe EnemyManager com alguns atributos, 
        //incluindo informações sobre o jogo (playing), imagens de inimigos e outros.
        //No construtor, inicializa variáveis e carrega imagens necessárias.

	public EnemyManager(Playing playing, PathPoint start, PathPoint end) {
		this.playing = playing;
		enemyImgs = new BufferedImage[4];
		this.start = start;
		this.end = end;

		loadEffectImg();
		loadEnemyImgs();
	}
        
        //Este método carrega uma imagem de um efeito lento a partir de um 
        //atlas de sprites usando a classe LoadSave.

	private void loadEffectImg() {
		slowEffect = LoadSave.getSpriteAtlas().getSubimage(32 * 9, 32 * 2, 32, 32);
	}
        
        //Este método carrega imagens de inimigos de diferentes atlas de 
        //sprites, subdividindo essas imagens para cada tipo de inimigo.

        private void loadEnemyImgs() {
            BufferedImage atlas2 = LoadSave.getSpriteAtlas2();
            BufferedImage atlas3 = LoadSave.getSpriteAtlas3();
            BufferedImage atlas4 = LoadSave.getSpriteAtlas4();
            BufferedImage atlas5 = LoadSave.getSpriteAtlas5();
            int spriteWidth = 250 / 5; // Divide a largura do sprite total (250) pelo número de unidades (5)
            int spriteHeight = 50;

            // Extrai subimagens para cada tipo de inimigo
            for (int i = 0; i < 1; i++) {
                enemyImgs[i] = atlas2.getSubimage(i * spriteWidth, 0, spriteWidth, spriteHeight);
            }
            for (int i = 1; i < 2; i++) {
                enemyImgs[i] = atlas3.getSubimage(i * spriteWidth, 0, spriteWidth, spriteHeight);
            }
            for (int i = 2; i < 3; i++) {
                enemyImgs[i] = atlas4.getSubimage(i * spriteWidth, 0, spriteWidth, spriteHeight);
            }
            for (int i = 3; i < 4; i++) {
                enemyImgs[i] = atlas5.getSubimage(i * spriteWidth, 0, spriteWidth, spriteHeight);
            }
        }
        
        //Este método percorre a lista de inimigos e atualiza o movimento de 
        //cada inimigo vivo.

	public void update() {

		for (Enemy e : enemies)
			if (e.isAlive())
				updateEnemyMove(e);

	}
        
        //Este método atualiza o movimento do inimigo com base na direção atual e na posição na tela.

	public void updateEnemyMove(Enemy e) {
		if (e.getLastDir() == -1)
			setNewDirectionAndMove(e);

		int newX = (int) (e.getX() + getSpeedAndWidth(e.getLastDir(), e.getEnemyType()));
		int newY = (int) (e.getY() + getSpeedAndHeight(e.getLastDir(), e.getEnemyType()));

		if (getTileType(newX, newY) == ROAD_TILE) {
			e.move(GetSpeed(e.getEnemyType()), e.getLastDir());
		} else if (isAtEnd(e)) {
			e.kill();
			playing.removeOneLife();
		} else {
			setNewDirectionAndMove(e);
		}
	}
        
        //Este método determina a nova direção do inimigo com base na posição atual e move o inimigo de acordo.

	private void setNewDirectionAndMove(Enemy e) {
		int dir = e.getLastDir();

		int xCord = (int) (e.getX() / 32);
		int yCord = (int) (e.getY() / 32);

		fixEnemyOffsetTile(e, dir, xCord, yCord);

		if (isAtEnd(e))
			return;

		if (dir == LEFT || dir == RIGHT) {
			int newY = (int) (e.getY() + getSpeedAndHeight(UP, e.getEnemyType()));
			if (getTileType((int) e.getX(), newY) == ROAD_TILE)
				e.move(GetSpeed(e.getEnemyType()), UP);
			else
				e.move(GetSpeed(e.getEnemyType()), DOWN);
		} else {
			int newX = (int) (e.getX() + getSpeedAndWidth(RIGHT, e.getEnemyType()));
			if (getTileType(newX, (int) e.getY()) == ROAD_TILE)
				e.move(GetSpeed(e.getEnemyType()), RIGHT);
			else
				e.move(GetSpeed(e.getEnemyType()), LEFT);

		}

	}
        
        //Este método ajusta a posição do inimigo em relação aos azulejos (tiles) com base na direção atual.

	private void fixEnemyOffsetTile(Enemy e, int dir, int xCord, int yCord) {
		switch (dir) {
		case RIGHT:
			if (xCord < 35)
				xCord++;
			break;
		case DOWN:
			if (yCord < 19)
				yCord++;
			break;
		}

		e.setPos(xCord * 32, yCord * 32);

	}
        
        //Este método verifica se o inimigo atingiu o final do caminho.

	private boolean isAtEnd(Enemy e) {
		if (e.getX() == end.getxCord() * 32)
			if (e.getY() == end.getyCord() * 32)
				return true;
		return false;
	}
        //Este método obtém o tipo de azulejo (tile) na posição especificada no jogo.

	private int getTileType(int x, int y) {
		return playing.getTileType(x, y);
	}
        
        //Esses métodos calculam a velocidade vertical e horizontal com base na direção e no tipo de inimigo.

	private float getSpeedAndHeight(int dir, int enemyType) {
		if (dir == UP)
			return -GetSpeed(enemyType);
		else if (dir == DOWN)
			return GetSpeed(enemyType) + 32;

		return 0;
	}

	private float getSpeedAndWidth(int dir, int enemyType) {
		if (dir == LEFT)
			return -GetSpeed(enemyType);
		else if (dir == RIGHT)
			return GetSpeed(enemyType) + 32;

		return 0;
	}
        
        //Esses métodos adicionam inimigos à lista de inimigos com base no tipo de inimigo especificado.

	public void spawnEnemy(int nextEnemy) {
		addEnemy(nextEnemy);
	}

	public void addEnemy(int enemyType) {

		int x = start.getxCord() * 32;
		int y = start.getyCord() * 32;

		switch (enemyType) {
		case DemonCiclop2:
			enemies.add(new DemonCiclop2(x, y, 0, this));
			break;
		case GiantFlam:
			enemies.add(new GiantFlam(x, y, 0, this));
			break;
		case GiantSpirit:
			enemies.add(new GiantSpirit(x, y, 0, this));
			break;
		case DemonCiclop:
			enemies.add(new DemonCiclop(x, y, 0, this));
			break;
		}

	}
        
        //Este método desenha inimigos vivos, barras de vida e efeitos na tela usando a classe Graphics.

	public void draw(Graphics g) {
		for (Enemy e : enemies) {
			if (e.isAlive()) {
				drawEnemy(e, g);
				drawHealthBar(e, g);
				drawEffects(e, g);
			}
		}
	}
        
        //Este método desenha efeitos especiais (como um efeito de desaceleração) em inimigos específicos.

	private void drawEffects(Enemy e, Graphics g) {
		if (e.isSlowed())
			g.drawImage(slowEffect, (int) e.getX(), (int) e.getY(), null);

	}
        
        //Este método desenha barras de vida coloridas acima dos inimigos, indicando sua saúde.

	private void drawHealthBar(Enemy e, Graphics g) {
		g.setColor(Color.red);
		g.fillRect((int) e.getX() + 16 - (getNewBarWidth(e) / 2), (int) e.getY() - 10, getNewBarWidth(e), 3);

	}
        
        //Este método calcula a largura da barra de vida com base na porcentagem de saúde do inimigo.

	private int getNewBarWidth(Enemy e) {
		return (int) (HPbarWidth * e.getHealthBarFloat());
	}
        
        //Este método desenha a imagem do inimigo na tela com base em seu tipo.

	private void drawEnemy(Enemy e, Graphics g) {
		g.drawImage(enemyImgs[e.getEnemyType()], (int) e.getX(), (int) e.getY(), null);
	}
        
        //Estes métodos fornecem acesso à lista de inimigos e calculam o número de inimigos vivos.

	public ArrayList<Enemy> getEnemies() {
		return enemies;
	}

	public int getAmountOfAliveEnemies() {
		int size = 0;
		for (Enemy e : enemies)
			if (e.isAlive())
				size++;

		return size;
	}

	public void rewardPlayer(int enemyType) {
		playing.rewardPlayer(enemyType);
	}

	public void reset() {
		enemies.clear();
	}

}

//Singleton: A classe EnemyManager é um singleton. Isso significa que apenas uma instância da 
//classe pode existir em um determinado momento. Isso é útil para gerenciar inimigos, 
//pois garante que apenas uma instância da classe esteja controlando a lista de inimigos e seus comportamentos.

//Factory: A classe EnemyManager usa um método spawnEnemy() para criar novos inimigos. Este método 
//é um exemplo de um padrão de fábrica. Um padrão de fábrica fornece uma maneira de criar objetos de 
//forma abstrata. No caso da classe EnemyManager, o método spawnEnemy() permite que a classe crie inimigos 
//de diferentes tipos, sem que o código que usa a classe precise saber como criar esses inimigos.
