package ui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class MyButton {

    // Atributos da classe representando as propriedades do botão
    public int x, y, width, height, id;
    private String text;
    private Rectangle bounds;
    private boolean mouseOver, mousePressed;

    // Construtor para botões normais
    public MyButton(String text, int x, int y, int width, int height) {
        this.text = text;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.id = -1;

        // Inicializa os limites do botão
        initBounds();
    }

    // Construtor para botões de tile
    public MyButton(String text, int x, int y, int width, int height, int id) {
        this.text = text;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.id = id;

        // Inicializa os limites do botão
        initBounds();
    }

    // Inicializa os limites do botão
    private void initBounds() {
        this.bounds = new Rectangle(x, y, width, height);
    }

    // Método para desenhar o botão
    public void draw(Graphics g) {
        // Desenha o corpo do botão
        drawBody(g);

        // Desenha a borda do botão
        drawBorder(g);

        // Desenha o texto do botão
        drawText(g);
    }

    // Desenha a borda do botão
    private void drawBorder(Graphics g) {
        // Define a cor da borda como preta
        g.setColor(Color.black);
        // Desenha a borda do botão
        g.drawRect(x, y, width, height);

        // Se o mouse estiver pressionado, desenha uma borda adicional
        if (mousePressed) {
            g.drawRect(x + 1, y + 1, width - 2, height - 2);
            g.drawRect(x + 2, y + 2, width - 4, height - 4);
        }
    }

    // Desenha o corpo do botão
    private void drawBody(Graphics g) {
        // Define a cor do corpo do botão como cinza se o mouse estiver sobre ele, caso contrário, branco
        if (mouseOver)
            g.setColor(Color.gray);
        else
            g.setColor(Color.WHITE);
        // Desenha o corpo do botão
        g.fillRect(x, y, width, height);
    }

    // Desenha o texto do botão
    private void drawText(Graphics g) {
        // Obtém as dimensões do texto para centralizá-lo no botão
        int w = g.getFontMetrics().stringWidth(text);
        int h = g.getFontMetrics().getHeight();
        // Desenha o texto centralizado no botão
        g.drawString(text, x - w / 2 + width / 2, y + h / 2 + height / 2);
    }

    // Reinicia as variáveis booleanas relacionadas ao mouse
    public void resetBooleans() {
        this.mouseOver = false;
        this.mousePressed = false;
    }

    // Define o texto do botão
    public void setText(String text) {
        this.text = text;
    }

    // Define se o mouse está pressionado sobre o botão
    public void setMousePressed(boolean mousePressed) {
        this.mousePressed = mousePressed;
    }

    // Define se o mouse está sobre o botão
    public void setMouseOver(boolean mouseOver) {
        this.mouseOver = mouseOver;
    }

    // Verifica se o mouse está sobre o botão
    public boolean isMouseOver() {
        return mouseOver;
    }

    // Verifica se o mouse está pressionado sobre o botão
    public boolean isMousePressed() {
        return mousePressed;
    }

    // Obtém os limites do botão
    public Rectangle getBounds() {
        return bounds;
    }

    // Obtém o ID do botão
    public int getId() {
        return id;
    }
}
