package scenes;

import java.awt.Graphics;
import main.Game;
import ui.MyButton;
import static main.GameStates.*;

//A classe Menu estende a classe abstrata GameScene por meio do comando extends. 
//Isso indica que Menu é uma especialização de GameScene e herda suas características e comportamentos. 
//A herança é uma forma de reutilização de código, permitindo que Menu 
//aproveite funcionalidades já definidas em GameScene.

// A classe Menu representa a cena do menu principal do jogo
public class Menu extends GameScene implements SceneMethods {

    // Botões do menu
    private MyButton bPlaying, bQuit;

    // Construtor da classe Menu
    public Menu(Game game) {
        super(game);
        initButtons();
    }

    // Inicializa os botões do menu
    private void initButtons() {

        int w = 150;
        int h = w / 3;
        int x = (896 + 128 + 128)/ 2 - w / 2;
        int y = 150;
        int yOffset = 100;

        // Inicializa os botões com os parâmetros especificados
        bPlaying = new MyButton("Jogar", x, y, w, h);
        bQuit = new MyButton("Sair", x, y + yOffset*2, w, h);

    }

    // Renderiza a cena do menu
    @Override
    public void render(Graphics g) {

        // Desenha os botões na tela
        drawButtons(g);

    }

    // Desenha os botões na tela
    private void drawButtons(Graphics g) {
        bPlaying.draw(g);
        bQuit.draw(g);
    }

    // Método chamado quando o mouse é clicado
    @Override
    public void mouseClicked(int x, int y) {

        // Verifica qual botão foi clicado e realiza a ação correspondente
        if (bPlaying.getBounds().contains(x, y))
            SetGameState(PLAYING);
        else if (bQuit.getBounds().contains(x, y))
            System.exit(0);
    }

    // Método chamado quando o mouse é movido
    @Override
    public void mouseMoved(int x, int y) {
        bPlaying.setMouseOver(false);
        bQuit.setMouseOver(false);

        // Verifica se o mouse está sobre algum botão e ajusta o estado correspondente
        if (bPlaying.getBounds().contains(x, y))
            bPlaying.setMouseOver(true);
        else if (bQuit.getBounds().contains(x, y))
            bQuit.setMouseOver(true);
    }

    // Método chamado quando o mouse é pressionado
    @Override
    public void mousePressed(int x, int y) {

        // Marca o botão que foi pressionado
        if (bPlaying.getBounds().contains(x, y))
            bPlaying.setMousePressed(true);
        else if (bQuit.getBounds().contains(x, y))
            bQuit.setMousePressed(true);

    }

    // Método chamado quando o mouse é liberado após ter sido pressionado
    @Override
    public void mouseReleased(int x, int y) {
        // Reseta o estado dos botões
        resetButtons();
    }

    // Reseta o estado dos botões
    private void resetButtons() {
        bPlaying.resetBooleans();
        bQuit.resetBooleans();
    }

    // Método chamado quando o mouse é arrastado
    @Override
    public void mouseDragged(int x, int y) {
        // TODO Auto-generated method stub
    }
}
