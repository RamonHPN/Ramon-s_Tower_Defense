package main;

import java.awt.Graphics;

public class Render {

    private Game game; // Referência à instância do jogo

    // Construtor
    public Render(Game game) {
        this.game = game; // Inicializa a referência ao jogo
    }

    // Método para renderizar com base no estado do jogo
    public void render(Graphics g) {
        switch (GameStates.gameState) {
            case MENU:
                game.getMenu().render(g); // Chama o método de renderização do estado do menu
                break;
            case PLAYING:
                game.getPlaying().render(g); // Chama o método de renderização do estado de jogo
                break;
            case GAME_OVER:
                game.getGameOver().render(g); // Chama o método de renderização do estado de game over
                break;
            default:
                break;
        }
    }
}
