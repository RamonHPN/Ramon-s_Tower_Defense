// Define o pacote 'helpz' para organização do código
package auxiliar;

// Declaração da classe utilitária 'Utilz'
public class Utilz {

    // Método para calcular a distância euclidiana entre dois pontos (x1, y1) e (x2, y2)
    public static int GetHypoDistance(float x1, float y1, float x2, float y2) {
        // Calcula as diferenças nas coordenadas x e y
        float xDiff = Math.abs(x1 - x2);
        float yDiff = Math.abs(y1 - y2);

        // Calcula e retorna a hipotenusa usando o teorema de Pitágoras
        return (int) Math.hypot(xDiff, yDiff);
    }
}