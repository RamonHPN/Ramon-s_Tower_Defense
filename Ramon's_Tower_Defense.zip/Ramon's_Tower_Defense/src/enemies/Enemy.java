// Define o pacote 'enemies' para organização do código
package enemies;

// Importa a classe Rectangle da biblioteca padrão Java
import java.awt.Rectangle;

// Importa a classe EnemyManager do pacote managers
import managers.EnemyManager;

// Importa as constantes de direção do pacote 'helpz.Constants.Direction'
import static auxiliar.Constants.Direction.*;

// Declara a classe abstrata 'Enemy'
public abstract class Enemy {
    // Atributos protegidos acessíveis pelas subclasses
    //Encapsulamento - Os atributos da classe Enemy são declarados como protegidos (protected), 
    //o que significa que eles podem ser acessados por subclasses, garantindo 
    //encapsulamento e controle de acesso.
    protected EnemyManager enemyManager;
    protected float x, y;
    protected Rectangle bounds;
    protected int health;
    protected int maxHealth;
    protected int ID;
    protected int enemyType;
    protected int lastDir;
    protected boolean alive = true;
    protected int slowTickLimit = 120;
    protected int slowTick = slowTickLimit;

    // Construtor da classe 'Enemy'
    public Enemy(float x, float y, int ID, int enemyType, EnemyManager enemyManager) {
        this.x = x;
        this.y = y;
        this.ID = ID;
        this.enemyType = enemyType;
        this.enemyManager = enemyManager;
        bounds = new Rectangle((int) x, (int) y, 32, 32);
        lastDir = -1;
        setStartHealth();
    }

    // Método privado para definir a saúde inicial
    private void setStartHealth() {
        health = auxiliar.Constants.Enemies.GetStartHealth(enemyType);
        maxHealth = health;
    }

    // Método para causar dano ao inimigo
    public void hurt(int dmg) {
        this.health -= dmg;
        if (health <= 0) {
            alive = false;
            enemyManager.rewardPlayer(enemyType);
        }
    }

    // Método para "matar" o inimigo
    public void kill() {
        alive = false;
        health = 0;
    }

    // Método para reduzir a velocidade do inimigo
    public void slow() {
        slowTick = 0;
    }

    // Método para mover o inimigo em uma direção específica
    public void move(float speed, int dir) {
        lastDir = dir;

        // Reduz a velocidade se o inimigo estiver sob efeito de "slow"
        if (slowTick < slowTickLimit) {
            slowTick++;
            speed *= 0.5f;
        }

        // Move o inimigo com base na direção
        switch (dir) {
            case LEFT:
                this.x -= speed;
                break;
            case UP:
                this.y -= speed;
                break;
            case RIGHT:
                this.x += speed;
                break;
            case DOWN:
                this.y += speed;
                break;
        }

        // Atualiza a posição do hitbox
        updateHitbox();
    }
    //O método move na classe Enemy é um exemplo de template method. 
    //O algoritmo para movimentar o inimigo é definido na classe pai (Enemy), 
    //mas parte do comportamento é delegado às subclasses, permitindo que 
    //elas forneçam implementações específicas para certas etapas.

    // Método privado para atualizar a posição do hitbox
    private void updateHitbox() {
        bounds.x = (int) x;
        bounds.y = (int) y;
    }

    // Método para definir a posição do inimigo
    public void setPos(int x, int y) {
        // Não use este método para mover o inimigo.
        this.x = x;
        this.y = y;
    }

    // Método para obter a porcentagem de vida como um número de ponto flutuante
    public float getHealthBarFloat() {
        return health / (float) maxHealth;
    }

    // Métodos getters para obter propriedades do inimigo
    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public Rectangle getBounds() {
        return bounds;
    }

    public int getHealth() {
        return health;
    }

    public int getID() {
        return ID;
    }

    public int getEnemyType() {
        return enemyType;
    }

    public int getLastDir() {
        return lastDir;
    }

    public boolean isAlive() {
        return alive;
    }

    public boolean isSlowed() {
        return slowTick < slowTickLimit;
    }
}
