package objects;

import java.awt.image.BufferedImage;

// Classe que representa um tile no jogo
public class Tile {

    // Array de sprites para tiles animados ou estáticos
    private BufferedImage[] sprite;

    // Identificador único do tile
    private int id;

    // Tipo do tile (usado para determinar características, como colisões)
    private int tileType;

    // Construtor para tiles estáticos
    public Tile(BufferedImage sprite, int id, int tileType) {
        // Inicializa o array de sprites com tamanho 1 e atribui o sprite fornecido
        this.sprite = new BufferedImage[1];
        this.sprite[0] = sprite;
        this.id = id;
        this.tileType = tileType;
    }

    // Construtor para tiles animados ou tiles com múltiplos sprites
    public Tile(BufferedImage[] sprite, int id, int tileType) {
        // Atribui o array de sprites fornecido
        this.sprite = sprite;
        this.id = id;
        this.tileType = tileType;
    }

    // Método para obter o tipo do tile
    public int getTileType() {
        return tileType;
    }

    // Método para obter um sprite específico com base no índice de animação
    public BufferedImage getSprite(int animationIndex) {
        return sprite[animationIndex];
    }

    // Método para obter o sprite (quando não há animação, retorna o primeiro sprite)
    public BufferedImage getSprite() {
        return sprite[0];
    }

    // Verifica se o tile possui animação (mais de um sprite)
    public boolean isAnimation() {
        return sprite.length > 1;
    }

    // Método para obter o identificador único do tile
    public int getId() {
        return id;
    }

}
