// Define o pacote 'inputs' para organização do código
package inputs;

// Importa classes necessárias da biblioteca padrão Java e classes do projeto 'main'
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import main.Game;
import main.GameStates;

// Declaração da classe 'MyMouseListener' que implementa as interfaces 'MouseListener' e 'MouseMotionListener'
public class MyMouseListener implements MouseListener, MouseMotionListener {

    private Game game;

    // Construtor que recebe uma instância da classe 'Game'
    public MyMouseListener(Game game) {
        this.game = game;
    }

    // Método chamado quando o mouse é arrastado
    @Override
    public void mouseDragged(MouseEvent e) {
        // Determina o estado do jogo e chama o método correspondente
        switch (GameStates.gameState) {
            case MENU:
                game.getMenu().mouseDragged(e.getX(), e.getY());
                break;
            case PLAYING:
                game.getPlaying().mouseDragged(e.getX(), e.getY());
                break;
            default:
                break;
        }
    }

    // Método chamado quando o mouse é movido
    @Override
    public void mouseMoved(MouseEvent e) {
        // Determina o estado do jogo e chama o método correspondente
        switch (GameStates.gameState) {
            case MENU:
                game.getMenu().mouseMoved(e.getX(), e.getY());
                break;
            case PLAYING:
                game.getPlaying().mouseMoved(e.getX(), e.getY());
                break;
            case GAME_OVER:
                game.getGameOver().mouseMoved(e.getX(), e.getY());
                break;
            default:
                break;
        }
    }

    // Método chamado quando um botão do mouse é clicado
    @Override
    public void mouseClicked(MouseEvent e) {
        // Verifica se o botão clicado é o botão esquerdo
        if (e.getButton() == MouseEvent.BUTTON1) {
            // Determina o estado do jogo e chama o método correspondente
            switch (GameStates.gameState) {
                case MENU:
                    game.getMenu().mouseClicked(e.getX(), e.getY());
                    break;
                case PLAYING:
                    game.getPlaying().mouseClicked(e.getX(), e.getY());
                    break;
                case GAME_OVER:
                    game.getGameOver().mouseClicked(e.getX(), e.getY());
                    break;
                default:
                    break;
            }
        }
    }

    // Método chamado quando um botão do mouse é pressionado
    @Override
    public void mousePressed(MouseEvent e) {
        // Determina o estado do jogo e chama o método correspondente
        switch (GameStates.gameState) {
            case MENU:
                game.getMenu().mousePressed(e.getX(), e.getY());
                break;
            case PLAYING:
                game.getPlaying().mousePressed(e.getX(), e.getY());
                break;
            case GAME_OVER:
                game.getGameOver().mousePressed(e.getX(), e.getY());
                break;
            default:
                break;
        }
    }

    // Método chamado quando um botão do mouse é liberado
    @Override
    public void mouseReleased(MouseEvent e) {
        // Determina o estado do jogo e chama o método correspondente
        switch (GameStates.gameState) {
            case MENU:
                game.getMenu().mouseReleased(e.getX(), e.getY());
                break;
            case PLAYING:
                game.getPlaying().mouseReleased(e.getX(), e.getY());
                break;
            case GAME_OVER:
                game.getGameOver().mouseReleased(e.getX(), e.getY());
                break;
            default:
                break;
        }
    }

    // Métodos não utilizados, mas exigidos pela interface
    @Override
    public void mouseEntered(MouseEvent e) {
        // Não utilizado
    }

    @Override
    public void mouseExited(MouseEvent e) {
        // Não utilizado
    }
}
