// Importações necessárias para a classe
package scenes;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

// Importação de classes do próprio projeto
import main.Game;
import ui.MyButton;
import static main.GameStates.*;

// Classe responsável pela cena de Game Over, que estende GameScene e implementa SceneMethods
public class GameOver extends GameScene implements SceneMethods {

    // Declaração do botão de Replay
    private MyButton bReplay;

    // Construtor da classe GameOver, recebe uma instância de Game como parâmetro
    public GameOver(Game game) {
        super(game); // Chama o construtor da classe pai (GameScene)
        initButtons(); // Inicializa os botões da cena
    }

    // Método privado para inicializar os botões da cena
    private void initButtons() {
        int w = 150; // Largura do botão
        int h = w / 3; // Altura do botão (1/3 da largura)
        int x = (896 + 128 + 128) / 2 - w / 2; // Posição X centralizada
        int y = 300; // Posição Y

        // Inicialização do botão de Replay
        bReplay = new MyButton("Reiniciar", x, y, w, h);
    }

    // Método de renderização da cena, responsável por desenhar na tela
    @Override
    public void render(Graphics g) {
        // Texto "Game Over" na tela
        g.setFont(new Font("LucidaSans", Font.BOLD, 50));
        g.setColor(Color.red);
        g.drawString("Game Over!", 425, 80);

        // Botões na tela
        g.setFont(new Font("LucidaSans", Font.BOLD, 20));
        bReplay.draw(g); // Desenha o botão de Replay
    }

    // Método para reiniciar o jogo ao clicar no botão de Replay
    private void replayGame() {
        // Reseta todos os elementos do jogo
        resetAll();

        // Altera o estado do jogo para "Playing"
        SetGameState(PLAYING);
    }

    // Método para resetar todos os elementos do jogo
    private void resetAll() {
        game.getPlaying().resetEverything(); // Reseta a instância de Playing
    }

    // Implementação dos métodos da interface SceneMethods

    // Método chamado quando o mouse é clicado
    @Override
    public void mouseClicked(int x, int y) {
        if (bReplay.getBounds().contains(x, y))
            replayGame(); // Chama replayGame() se o clique estiver dentro do botão de Replay
    }

    // Método chamado quando o mouse é movido
    @Override
    public void mouseMoved(int x, int y) {
        bReplay.setMouseOver(false); // Reseta o estado de "mouse over" do botão de Replay

        // Define o estado de "mouse over" do botão de Replay se o mouse estiver sobre ele
        if (bReplay.getBounds().contains(x, y))
            bReplay.setMouseOver(true);
    }

    // Método chamado quando o mouse é pressionado
    @Override
    public void mousePressed(int x, int y) {
        if (bReplay.getBounds().contains(x, y))
            bReplay.setMousePressed(true); // Define o estado de "mouse pressed" do botão de Replay
    }

    // Método chamado quando o mouse é liberado
    @Override
    public void mouseReleased(int x, int y) {
        bReplay.resetBooleans(); // Reseta os estados de "mouse over" e "mouse pressed" dos botões
    }

    // Método chamado quando o mouse é arrastado (não implementado)
    @Override
    public void mouseDragged(int x, int y) {
        // TODO: Implementação necessária
    }
}
