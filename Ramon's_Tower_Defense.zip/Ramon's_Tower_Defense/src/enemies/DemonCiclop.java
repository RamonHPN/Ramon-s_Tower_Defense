// Define o pacote 'enemies' para organização do código
package enemies;

// Importa a classe EnemyManager do pacote managers
import managers.EnemyManager;

// Importa a constante 'DemonCiclop' do pacote 'helpz.Constants.Enemies'
import static auxiliar.Constants.Enemies.DemonCiclop;

// Declara a classe 'DemonCiclop' que estende a classe 'Enemy'
public class DemonCiclop extends Enemy {

    // Construtor da classe
    public DemonCiclop(float x, float y, int ID, EnemyManager em) {
        // Chama o construtor da classe pai (Enemy) passando os parâmetros necessários
        super(x, y, ID, DemonCiclop, em);
    }

}
//A classe 'DemonCiclop' estende a classe 'Enemy', indicando que herda comportamentos e propriedades dessa classe pai.