package managers;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import enemies.Enemy;
import auxiliar.LoadSave;
import objects.Projectile;
import objects.Tower;
import scenes.Playing;
import static auxiliar.Constants.Towers.*;
import static auxiliar.Constants.Projectiles.*;

// Esta classe gerencia os projéteis no jogo, incluindo criação, atualização e renderização.

public class ProjectileManager {

	private Playing playing;
	private ArrayList<Projectile> projectiles = new ArrayList<>();
	private ArrayList<Explosion> explosions = new ArrayList<>();
	private BufferedImage[] proj_imgs, explo_imgs;
	private int proj_id = 0;
        
// O construtor inicializa os atributos da classe e importa as imagens necessárias.
	public ProjectileManager(Playing playing) {
		this.playing = playing;
		importImgs();
	}

// Este método importa imagens de projéteis e explosões a partir de um atlas de sprites usando a classe LoadSave.
	private void importImgs() {
		BufferedImage atlas = LoadSave.getSpriteAtlas();
		proj_imgs = new BufferedImage[3];

		for (int i = 0; i < 3; i++)
			proj_imgs[i] = atlas.getSubimage((7 + i) * 32, 32, 32, 32);
		importExplosion(atlas);
	}

	private void importExplosion(BufferedImage atlas) {
		explo_imgs = new BufferedImage[7];

		for (int i = 0; i < 7; i++)
			explo_imgs[i] = atlas.getSubimage(i * 32, 32 * 2, 32, 32);

	}

// Este método cria um novo projétil com base em uma torre e um inimigo alvo.        
	public void newProjectile(Tower t, Enemy e) {
		int type = getProjType(t);

		int xDist = (int) (t.getX() - e.getX());
		int yDist = (int) (t.getY() - e.getY());
		int totDist = Math.abs(xDist) + Math.abs(yDist);

		float xPer = (float) Math.abs(xDist) / totDist;

		float xSpeed = xPer * auxiliar.Constants.Projectiles.GetSpeed(type);
		float ySpeed = auxiliar.Constants.Projectiles.GetSpeed(type) - xSpeed;

		if (t.getX() > e.getX())
			xSpeed *= -1;
		if (t.getY() > e.getY())
			ySpeed *= -1;

		float rotate = 0;

		if (type == ARROW) {
			float arcValue = (float) Math.atan(yDist / (float) xDist);
			rotate = (float) Math.toDegrees(arcValue);

			if (xDist < 0)
				rotate += 180;
		}

		projectiles.add(new Projectile(t.getX() + 16, t.getY() + 16, xSpeed, ySpeed, t.getDmg(), rotate, proj_id++, type));

	}
 // Este método atualiza a posição dos projéteis e verifica se eles atingem inimigos ou saem dos limites do jogo.

	public void update() {
		for (Projectile p : projectiles)
			if (p.isActive()) {
				p.move();
				if (isProjHittingEnemy(p)) {
					p.setActive(false);
					if (p.getProjectileType() == BOMB) {
						explosions.add(new Explosion(p.getPos()));
						explodeOnEnemies(p);
					}
				} else if (isProjOutsideBounds(p)) {
					p.setActive(false);
				}
			}

		for (Explosion e : explosions)
			if (e.getIndex() < 7)
				e.update();
	}
        
// Este método realiza uma explosão em inimigos dentro do raio de um projétil do tipo BOMB.

	private void explodeOnEnemies(Projectile p) {
		for (Enemy e : playing.getEnemyManger().getEnemies()) {
			if (e.isAlive()) {
				float radius = 40.0f;

				float xDist = Math.abs(p.getPos().x - e.getX());
				float yDist = Math.abs(p.getPos().y - e.getY());

				float realDist = (float) Math.hypot(xDist, yDist);

				if (realDist <= radius)
					e.hurt(p.getDmg());
			}

		}

	}
// Este método verifica se um projétil atinge um inimigo.
	private boolean isProjHittingEnemy(Projectile p) {
		for (Enemy e : playing.getEnemyManger().getEnemies()) {
			if (e.isAlive())
				if (e.getBounds().contains(p.getPos())) {
					e.hurt(p.getDmg());
					if (p.getProjectileType() == CHAINS)
						e.slow();

					return true;
				}
		}
		return false;
	}
// Este método verifica se um projétil está fora dos limites do jogo.

	private boolean isProjOutsideBounds(Projectile p) {
		if (p.getPos().x >= 0)
			if (p.getPos().x <= 896 + 128 + 128)
				if (p.getPos().y >= 0)
					if (p.getPos().y <= 800)
						return false;
		return true;
	}
// Este método desenha os projéteis na tela.

	public void draw(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;

		for (Projectile p : projectiles)
			if (p.isActive()) {
				if (p.getProjectileType() == ARROW) {
					g2d.translate(p.getPos().x, p.getPos().y);
					g2d.rotate(Math.toRadians(p.getRotation()));
					g2d.drawImage(proj_imgs[p.getProjectileType()], -16, -16, null);
					g2d.rotate(-Math.toRadians(p.getRotation()));
					g2d.translate(-p.getPos().x, -p.getPos().y);
				} else {
					g2d.drawImage(proj_imgs[p.getProjectileType()], (int) p.getPos().x - 16, (int) p.getPos().y - 16, null);
				}
			}

		drawExplosions(g2d);

	}
        
// Este método desenha as explosões na tela.

	private void drawExplosions(Graphics2D g2d) {
		for (Explosion e : explosions)
			if (e.getIndex() < 7)
				g2d.drawImage(explo_imgs[e.getIndex()], (int) e.getPos().x - 16, (int) e.getPos().y - 16, null);
	}
        
 // Este método determina o tipo de projétil com base no tipo de torre.

	private int getProjType(Tower t) {
		switch (t.getTowerType()) {
		case ARCHER:
			return ARROW;
		case CANNON:
			return BOMB;
		case WIZARD:
			return CHAINS;
		}
		return 0;
	}
// Classe interna que representa uma explosão.

	public class Explosion {

		private Point2D.Float pos;
		private int exploTick, exploIndex;

		public Explosion(Point2D.Float pos) {
			this.pos = pos;
		}
                // Este método atualiza o índice da explosão.
                
		public void update() {
			exploTick++;
			if (exploTick >= 6) {
				exploTick = 0;
				exploIndex++;
			}
		}
                
                // Métodos getter para obter o índice da explosão e a posição.
		public int getIndex() {
			return exploIndex;
		}

		public Point2D.Float getPos() {
			return pos;
		}
	}
// Este método limpa a lista de projéteis e explosões, reinicializando o identificador de projéteis.

	public void reset() {
		projectiles.clear();
		explosions.clear();

		proj_id = 0;
	}

}

//Padrão Observer: A classe ProjectileManager observa o estado dos projéteis (Projectile e Explosion). 
//Quando um projétil atinge um inimigo ou sai dos limites, o ProjectileManager reage a esses eventos, 
//atualizando o estado do jogo conforme necessário.

//Padrão Factory Method: O método newProjectile atua como um método de criação de um novo projétil. 
//Dependendo do tipo de torre, diferentes tipos de projéteis são criados. Esse método encapsula a 
//lógica de criação de objetos relacionados.

//Padrão Strategy:
//A escolha do tipo de projétil (ARROW, BOMB, CHAINS) é baseada no tipo de torre (ARCHER, CANNON, WIZARD). 
//Isso reflete um padrão de estratégia, onde diferentes estratégias (tipos de projéteis) são encapsuladas e 
//podem ser alteradas dinamicamente.
