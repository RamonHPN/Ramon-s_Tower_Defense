// Define o pacote 'helpz' para organização do código
package auxiliar;

// Importa classes necessárias da biblioteca padrão Java
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

// Declaração da classe utilitária 'ImgFix'
public class ImgFix {
    
    //s operações são encapsuladas em métodos, como getRotImg, buildImg, getBuildRotImg

    // Método para rotacionar uma imagem
    public static BufferedImage getRotImg(BufferedImage img, int rotAngle) {
        int w = img.getWidth();
        int h = img.getHeight();

        // Cria uma nova imagem com o mesmo tipo da imagem original
        BufferedImage newImg = new BufferedImage(w, h, img.getType());
        Graphics2D g2d = newImg.createGraphics();

        // Rotaciona a imagem
        g2d.rotate(Math.toRadians(rotAngle), w / 2, h / 2);
        g2d.drawImage(img, 0, 0, null);
        g2d.dispose();

        return newImg;
    }

    // Método para construir uma imagem a partir de um array de imagens
    public static BufferedImage buildImg(BufferedImage[] imgs) {
        int w = imgs[0].getWidth();
        int h = imgs[0].getHeight();

        // Cria uma nova imagem com o mesmo tipo da primeira imagem no array
        BufferedImage newImg = new BufferedImage(w, h, imgs[0].getType());
        Graphics2D g2d = newImg.createGraphics();

        // Desenha cada imagem no array na nova imagem
        for (BufferedImage img : imgs) {
            g2d.drawImage(img, 0, 0, null);
        }

        g2d.dispose();
        return newImg;
    }

    // Método para rotacionar apenas a segunda imagem em um array de imagens
    public static BufferedImage getBuildRotImg(BufferedImage[] imgs, int rotAngle, int rotAtIndex) {
        int w = imgs[0].getWidth();
        int h = imgs[0].getHeight();

        // Cria uma nova imagem com o mesmo tipo da primeira imagem no array
        BufferedImage newImg = new BufferedImage(w, h, imgs[0].getType());
        Graphics2D g2d = newImg.createGraphics();

        // Desenha cada imagem no array, aplicando rotação apenas à imagem no índice específico
        for (int i = 0; i < imgs.length; i++) {
            if (rotAtIndex == i)
                g2d.rotate(Math.toRadians(rotAngle), w / 2, h / 2);
            g2d.drawImage(imgs[i], 0, 0, null);
            if (rotAtIndex == i)
                g2d.rotate(Math.toRadians(-rotAngle), w / 2, h / 2);
        }

        g2d.dispose();
        return newImg;
    }

    // Método para rotacionar apenas a segunda imagem em um array de imagens com animação
    public static BufferedImage[] getBuildRotImg(BufferedImage[] imgs, BufferedImage secondImage, int rotAngle) {
        int w = imgs[0].getWidth();
        int h = imgs[0].getHeight();

        // Cria um array de imagens para armazenar os resultados
        BufferedImage[] arr = new BufferedImage[imgs.length];

        // Para cada imagem no array
        for (int i = 0; i < imgs.length; i++) {
            // Cria uma nova imagem com o mesmo tipo da primeira imagem no array
            BufferedImage newImg = new BufferedImage(w, h, imgs[0].getType());
            Graphics2D g2d = newImg.createGraphics();

            // Desenha a imagem original do array
            g2d.drawImage(imgs[i], 0, 0, null);
            // Rotaciona a imagem apenas se for a segunda imagem no array
            
            g2d.rotate(Math.toRadians(rotAngle), w / 2, h / 2);
            // Desenha a segunda imagem
            g2d.drawImage(secondImage, 0, 0, null);
            g2d.dispose();

            // Armazena o resultado no array
            arr[i] = newImg;
        }

        return arr;
    }
}
