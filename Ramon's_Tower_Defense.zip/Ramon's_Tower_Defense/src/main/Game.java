package main;
//padrão Observer: onde objetos observadores (como Playing e GameOver) registram
//interesse em mudanças de estado (como GameStates). Quando o estado muda, os 
//objetos observadores são notificados e respondem de acordo.

// Importa classes necessárias da biblioteca padrão Java
import javax.swing.JFrame;

// Importa classes do projeto 'managers' e 'scenes'
import managers.TileManager;
import scenes.GameOver;
import scenes.Menu;
import scenes.Playing;

// Declaração da classe 'Game', que estende JFrame e implementa Runnable
public class Game extends JFrame implements Runnable {

    private GameScreen gameScreen;
    private Thread gameThread;

    // Constantes para a taxa de quadros por segundo (FPS) e atualizações por segundo (UPS)
    private final double FPS_SET = 120.0;
    private final double UPS_SET = 60.0;

    // Instâncias de classes
    private Render render;
    private Menu menu;
    private Playing playing;
    private GameOver gameOver;

    private TileManager tileManager;

    // Construtor da classe
    public Game() {
        initClasses(); // Inicializa as instâncias das classes
        

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setTitle("Ramon's Defense");
        add(gameScreen);
        pack();
        setVisible(true);
    }

    // Método para inicializar as instâncias das classes
    private void initClasses() {
        tileManager = new TileManager();
        render = new Render(this);
        gameScreen = new GameScreen(this);
        menu = new Menu(this);
        playing = new Playing(this);
        gameOver = new GameOver(this);
    }

    // Método para iniciar o jogo
    private void start() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    // Método para atualizar o estado do jogo
    private void updateGame() {
        switch (GameStates.gameState) {
            case MENU:
                break;
            case PLAYING:
                playing.update();
                break;
            default:
                break;
        }
    }

    // Método principal que inicia o jogo
    public static void main(String[] args) {
        Game game = new Game();
        game.gameScreen.initInputs();
        game.start();
    }

    // Método principal do loop de jogo
    @Override
    public void run() {
        // Variáveis para controlar o tempo
        double timePerFrame = 1000000000.0 / FPS_SET;
        double timePerUpdate = 1000000000.0 / UPS_SET;
        long lastFrame = System.nanoTime();
        long lastUpdate = System.nanoTime();
        long lastTimeCheck = System.currentTimeMillis();
        int frames = 0;
        int updates = 0;
        long now;

        while (true) {
            now = System.nanoTime();

            // Renderiza a tela
            if (now - lastFrame >= timePerFrame) {
                repaint();
                lastFrame = now;
                frames++;
            }

            // Atualiza o estado do jogo
            if (now - lastUpdate >= timePerUpdate) {
                updateGame();
                lastUpdate = now;
                updates++;
            }

            // Exibe informações de FPS e UPS a cada segundo
            if (System.currentTimeMillis() - lastTimeCheck >= 1000) {
                System.out.println("FPS: " + frames + " | UPS: " + updates);
                frames = 0;
                updates = 0;
                lastTimeCheck = System.currentTimeMillis();
            }
        }
    }

    // Getters e setters
    public Render getRender() {
        return render;
    }

    public Menu getMenu() {
        return menu;
    }

    public Playing getPlaying() {
        return playing;
    }

    public GameOver getGameOver() {
        return gameOver;
    }

    public TileManager getTileManager() {
        return tileManager;
    }
}
