package enemies;


import managers.EnemyManager;
import static auxiliar.Constants.Enemies.GiantSpirit;

public class GiantSpirit extends Enemy {

	public GiantSpirit(float x, float y, int ID,EnemyManager em) {
		super(x, y, ID, GiantSpirit,em);
		
	}

}
