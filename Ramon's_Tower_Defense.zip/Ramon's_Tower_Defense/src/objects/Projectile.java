package objects;

import java.awt.geom.Point2D;

// Classe que representa um projétil no jogo
public class Projectile {

    // Posição do projétil
    private Point2D.Float pos;
    
    // Identificador único do projétil
    private int id;
    
    // Tipo do projétil
    private int projectileType;
    
    // Dano causado pelo projétil
    private int dmg;
    
    // Velocidades nas direções x e y
    private float xSpeed, ySpeed;
    
    // Rotação do projétil
    private float rotation;
    
    // Indica se o projétil está ativo
    private boolean active = true;

    // Construtor da classe Projectile
    public Projectile(float x, float y, float xSpeed, float ySpeed, int dmg, float rotation, int id, int projectileType) {
        pos = new Point2D.Float(x, y);
        this.xSpeed = xSpeed;
        this.ySpeed = ySpeed;
        this.dmg = dmg;
        this.rotation = rotation;
        this.id = id;
        this.projectileType = projectileType;
    }

    // Move o projétil com base nas velocidades x e y
    public void move() {
        pos.x += xSpeed;
        pos.y += ySpeed;
    }

    // Métodos Getters e Setters para acessar e modificar atributos privados

    public Point2D.Float getPos() {
        return pos;
    }

    public void setPos(Point2D.Float pos) {
        this.pos = pos;
    }

    public int getId() {
        return id;
    }

    public int getProjectileType() {
        return projectileType;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public int getDmg() {
        return dmg;
    }

    public float getRotation() {
        return rotation;
    }
}
