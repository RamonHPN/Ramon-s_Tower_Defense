// Importa as classes necessárias
package ui;

// Importa as classes estáticas necessárias de GameStates
import static main.GameStates.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.text.DecimalFormat;

// Importa a classe Tower do pacote objects e a classe Playing do pacote scenes
import objects.Tower;
import scenes.Playing;

// A classe ActionBar representa a barra de ação no jogo
public class ActionBar extends Bar {

	// Referência para a instância da classe Playing
	private Playing playing;
	
	// Botões do menu e de pausa
	private MyButton bMenu, bPause;

	// Array de botões para seleção de torres
	private MyButton[] towerButtons;
	
	// Torres selecionada e exibida
	private Tower selectedTower;
	private Tower displayedTower;

	// Formatador decimal para exibição de números formatados
	private DecimalFormat formatter;

	// Variáveis para controle de ouro, exibição de custo da torre, tipo do custo e vidas
	private int trocados = 150;
	private boolean showTowerCost;
	private int towerCostType;
	private int lives = 3;

	// Construtor da classe ActionBar
	public ActionBar(int x, int y, int width, int height, Playing playing) {
		// Chama o construtor da superclasse Bar
		super(x, y, width, height);
		this.playing = playing;
		formatter = new DecimalFormat("0.0");

		// Inicializa os botões
		initButtons();
	}

	// Método para resetar todos os valores da ActionBar
	public void resetEverything() {
		lives = 3;
		towerCostType = 0;
		showTowerCost = false;
		trocados = 150;
		selectedTower = null;
		displayedTower = null;
	}

	// Método para inicializar os botões
	private void initButtons() {
		bMenu = new MyButton("Menu", 2, 642, 100, 30);
		bPause = new MyButton("Pause", 2, 682, 100, 30);

		towerButtons = new MyButton[3];

		int w = 50;
		int h = 50;
		int xStart = 500; //110
		int yStart = 650;
		int xOffset = (int) (w * 1.1f);

		for (int i = 0; i < towerButtons.length; i++)
			towerButtons[i] = new MyButton("", xStart + xOffset * i, yStart, w, h, i);
	}

	// Método para remover uma vida
	public void removeOneLife() {
		lives--;
		if (lives <= 0)
			SetGameState(GAME_OVER);
	}

	// Método para desenhar os botões na tela
	private void drawButtons(Graphics g) {
		//bMenu.draw(g);
		//bPause.draw(g);

		for (MyButton b : towerButtons) {
			g.setColor(Color.gray);
			g.fillRect(b.x, b.y, b.width, b.height);
			g.drawImage(playing.getTowerManager().getTowerImgs()[b.getId()], b.x, b.y, b.width, b.height, null);
			drawButtonFeedback(g, b);
		}
	}

	// Método para desenhar os elementos da ActionBar na tela
	public void draw(Graphics g) {
		// Desenha o fundo da ActionBar
		g.setColor(new Color(82, 183, 136));
		g.fillRect(x, y, width, height);

		// Desenha os botões
		drawButtons(g);

		// Desenha a torre exibida
		drawDisplayedTower(g);

		// Exibe informações sobre a onda
		drawWaveInfo(g);

		// Exibe a quantidade de ouro
		drawGoldAmount(g);

		// Desenha o custo da torre se estiver visível
		if (showTowerCost)
			drawTowerCost(g);

		// Exibe texto de jogo pausado se o jogo estiver pausado
		if (playing.isGamePaused()) {
			g.setColor(Color.black);
			g.drawString("Pause", 110, 790);
		}

		// Exibe o número de vidas
		g.setColor(Color.black);
		g.drawString("vidas: " + lives, 110, 700);
	}

	// Método para desenhar o custo da torre na tela
	private void drawTowerCost(Graphics g) {
		g.setColor(Color.gray);
		g.fillRect(670, 650, 130, 50);
		g.setColor(Color.black);
		g.drawRect(670, 650, 130, 50);

		//g.drawString("" + getTowerCostName(), 675, 670);
		g.drawString("custo: R$" + getTowerCostCost(), 675, 680);

		// Mostra isso se o jogador não tiver ouro suficiente para a torre selecionada.
		if (isTowerCostMoreThanCurrentGold()) {
			g.setColor(Color.RED);
			g.drawString("Dinheiro insuficiente", 660, 725);
		}
	}

	// Verifica se o custo da torre é maior que o ouro atual do jogador
	private boolean isTowerCostMoreThanCurrentGold() {
		return getTowerCostCost() > trocados;
	}

	// Obtém o nome da torre para exibição
//	private String getTowerCostName() {
//		return auxiliar.Constants.Towers.GetName(towerCostType);
//	}

	// Obtém o custo da torre
	private int getTowerCostCost() {
		return auxiliar.Constants.Towers.GetTowerCost(towerCostType);
	}

	// Exibe a quantidade de ouro do jogador
	private void drawGoldAmount(Graphics g) {
		g.drawString("Trocados: R$ " + trocados, 110, 675);
	}

	// Exibe informações sobre a onda atual
	private void drawWaveInfo(Graphics g) {
		g.setColor(Color.black);
		g.setFont(new Font("LucidaSans", Font.BOLD, 20));
		//drawWaveTimerInfo(g);
		drawEnemiesLeftInfo(g);
		drawWavesLeftInfo(g);
	}

	// Exibe informações sobre as ondas restantes
	private void drawWavesLeftInfo(Graphics g) {
		int current = playing.getWaveManager().getWaveIndex();
		int size = playing.getWaveManager().getWaves().size();
		g.drawString("Wave " + (current + 1) + " / " + size, 950, 675);
	}

	// Exibe informações sobre os inimigos restantes
	private void drawEnemiesLeftInfo(Graphics g) {
		int remaining = playing.getEnemyManger().getAmountOfAliveEnemies();
		g.drawString("N° Inimigos: " + remaining, 930, 700);
	}

	// Exibe informações sobre o tempo restante da onda
//	private void drawWaveTimerInfo(Graphics g) {
//		if (playing.getWaveManager().isWaveTimerStarted()) {
//			float timeLeft = playing.getWaveManager().getTimeLeft();
//			String formattedText = formatter.format(timeLeft);
//			g.drawString("Time Left: " + formattedText, 425, 750);
//		}
//	}

	// Desenha a torre exibida na tela
	private void drawDisplayedTower(Graphics g) {
		if (displayedTower != null) {
			drawDisplayedTowerBorder(g);
			drawDisplayedTowerRange(g);
		}
	}

	// Desenha a borda da torre exibida
	private void drawDisplayedTowerBorder(Graphics g) {
		g.setColor(Color.CYAN);
		g.drawRect(displayedTower.getX(), displayedTower.getY(), 32, 32);
	}

	// Desenha o alcance da torre exibida
	private void drawDisplayedTowerRange(Graphics g) {
		g.setColor(Color.white);
		g.drawOval(
			displayedTower.getX() + 16 - (int) (displayedTower.getRange() * 2) / 2,
			displayedTower.getY() + 16 - (int) (displayedTower.getRange() * 2) / 2,
			(int) displayedTower.getRange() * 2,
			(int) displayedTower.getRange() * 2
		);
	}

	// Exibe a torre quando selecionada
	public void displayTower(Tower t) {
		displayedTower = t;
	}
        private void togglePause() {
		playing.setGamePaused(!playing.isGamePaused());

		if (playing.isGamePaused())
			bPause.setText("Unpause");
		else
			bPause.setText("Pause");

	}

	// Manipula o evento de clique do mouse
	public void mouseClicked(int x, int y) {
		if (bMenu.getBounds().contains(x, y))
			SetGameState(MENU);
		else if (bPause.getBounds().contains(x, y))
			togglePause();
		else {
			if (displayedTower != null) {
			}
			for (MyButton b : towerButtons) {
				if (b.getBounds().contains(x, y)) {
					if (!isGoldEnoughForTower(b.getId()))
						return;
					selectedTower = new Tower(0, 0, -1, b.getId());
					playing.setSelectedTower(selectedTower);
					return;
				}
			}
		}
	}

	// Verifica se o jogador tem ouro suficiente para construir a torre
	private boolean isGoldEnoughForTower(int towerType) {
		return trocados >= auxiliar.Constants.Towers.GetTowerCost(towerType);
	}

	// Manipula o evento de movimento do mouse
	public void mouseMoved(int x, int y) {
		bMenu.setMouseOver(false);
		bPause.setMouseOver(false);
		showTowerCost = false;

		for (MyButton b : towerButtons)
			b.setMouseOver(false);

		if (bMenu.getBounds().contains(x, y))
			bMenu.setMouseOver(true);
		else if (bPause.getBounds().contains(x, y))
			bPause.setMouseOver(true);
		else {
			if (displayedTower != null) {
			}
			for (MyButton b : towerButtons)
				if (b.getBounds().contains(x, y)) {
					b.setMouseOver(true);
					showTowerCost = true;
					towerCostType = b.getId();
					return;
				}
		}
	}

	// Manipula o evento de pressionar o botão do mouse
	public void mousePressed(int x, int y) {
		if (bMenu.getBounds().contains(x, y))
			bMenu.setMousePressed(true);
		else if (bPause.getBounds().contains(x, y))
			bPause.setMousePressed(true);
		else {
			if (displayedTower != null) {
			}
			for (MyButton b : towerButtons)
				if (b.getBounds().contains(x, y)) {
					b.setMousePressed(true);
					return;
				}
		}
	}

	// Manipula o evento de liberação do botão do mouse
	public void mouseReleased(int x, int y) {
		bMenu.resetBooleans();
		bPause.resetBooleans();
		for (MyButton b : towerButtons)
			b.resetBooleans();
	}

	// Paga pelo custo da torre
	public void payForTower(int towerType) {
		this.trocados -= auxiliar.Constants.Towers.GetTowerCost(towerType);
	}

	// Adiciona ouro ao jogador
	public void addGold(int getReward) {
		this.trocados += getReward;
	}

	// Obtém o número de vidas do jogador
	public int getLives() {
		return lives;
	}
}
