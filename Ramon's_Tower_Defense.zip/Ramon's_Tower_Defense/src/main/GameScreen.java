package main;

import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;

import inputs.KeyboardListener;
import inputs.MyMouseListener;

public class GameScreen extends JPanel {

    private Game game; // Referência à instância do jogo
    private Dimension size; // Tamanho da tela

    private MyMouseListener myMouseListener; // Ouvinte de mouse
    private KeyboardListener keyboardListener; // Ouvinte de teclado

    // Construtor
    public GameScreen(Game game) {
        this.game = game; // Inicializa a referência ao jogo
        setPanelSize(); // Configura o tamanho do painel
    }

    // Método para inicializar os ouvintes de entrada
    public void initInputs() {
        myMouseListener = new MyMouseListener(game); // Cria um novo ouvinte de mouse
        keyboardListener = new KeyboardListener(game); // Cria um novo ouvinte de teclado

        // Adiciona os ouvintes ao painel
        addMouseListener(myMouseListener);
        addMouseMotionListener(myMouseListener);
        addKeyListener(keyboardListener);

        requestFocus(); // Solicita o foco para o painel para garantir que os ouvintes funcionem corretamente
    }

    // Método para configurar o tamanho do painel
    private void setPanelSize() {
        size = new Dimension(896 + 128 + 128, 800); // Define o tamanho da tela

        // Configura o tamanho mínimo, preferido e máximo do painel
        setMinimumSize(size);
        setPreferredSize(size);
        setMaximumSize(size);
    }

    // Método chamado automaticamente para renderizar o painel
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Chama o método de renderização do jogo
        game.getRender().render(g);
    }
}
