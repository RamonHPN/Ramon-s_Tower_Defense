package enemies;


import managers.EnemyManager;
import static auxiliar.Constants.Enemies.GiantFlam;

public class GiantFlam extends Enemy {

	public GiantFlam(float x, float y, int ID, EnemyManager em) {
		super(x, y, ID, GiantFlam,em);
		
	}

}
