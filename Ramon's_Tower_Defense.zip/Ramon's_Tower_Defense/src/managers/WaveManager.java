package managers;

import java.util.ArrayList;
import java.util.Arrays;

import objects.Wave;
import scenes.Playing;

// Gerencia as ondas de inimigos no jogo
public class WaveManager {

    private Playing playing; // Referência à instância da classe Playing
    private ArrayList<Wave> waves = new ArrayList<>(); // Lista de objetos Wave representando as ondas de inimigos
    private int enemySpawnTickLimit = 60 * 1; // Limite de ticks para o próximo spawn de inimigo
    private int enemySpawnTick = enemySpawnTickLimit; // Contador de ticks para controlar o spawn de inimigos
    private int enemyIndex, waveIndex; // Índices para rastrear o inimigo atual e a onda atual
    private int waveTickLimit = 60; // Limite de ticks para o início da próxima onda
    private int waveTick = 0; // Contador de ticks para rastrear o tempo decorrido desde o início da onda
    private boolean waveStartTimer, waveTickTimerOver; // Flags para controlar o início e término do temporizador da onda

    // Construtor da classe WaveManager
    public WaveManager(Playing playing) {
        this.playing = playing;
        createWaves(); // Inicializa as ondas
    }

    // Método para atualizar o estado das ondas
    public void update() {
        if (enemySpawnTick < enemySpawnTickLimit)
            enemySpawnTick++;

        if (waveStartTimer) {
            waveTick++;
            if (waveTick >= waveTickLimit) {
                waveTickTimerOver = true;
            }
        }
    }

    // Método para incrementar o índice da onda
    public void increaseWaveIndex() {
        waveIndex++;
        waveTick = 0;
        waveTickTimerOver = false;
        waveStartTimer = false;
    }

    // Método para verificar se o temporizador da onda expirou
    public boolean isWaveTimerOver() {
        return waveTickTimerOver;
    }

    // Método para iniciar o temporizador da onda
    public void startWaveTimer() {
        waveStartTimer = true;
    }

    // Método para obter o próximo inimigo na sequência da onda
    public int getNextEnemy() {
        enemySpawnTick = 0;
        return waves.get(waveIndex).getEnemyList().get(enemyIndex++);
    }

    // Método para criar as ondas com sequências específicas de inimigos
    private void createWaves() {
        waves.add(new Wave(new ArrayList<>(Arrays.asList(0, 0, 1, 1, 1))));
        waves.add(new Wave(new ArrayList<>(Arrays.asList(0, 0, 0, 1, 1, 2))));
        waves.add(new Wave(new ArrayList<>(Arrays.asList(0, 0, 1, 2, 2, 2))));
        waves.add(new Wave(new ArrayList<>(Arrays.asList(0, 0, 0, 0, 1, 1))));
        waves.add(new Wave(new ArrayList<>(Arrays.asList(0, 0, 0, 0, 1, 1, 1, 1))));
        waves.add(new Wave(new ArrayList<>(Arrays.asList(0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1))));
        waves.add(new Wave(new ArrayList<>(Arrays.asList(0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1))));
        waves.add(new Wave(new ArrayList<>(Arrays.asList(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1))));
        waves.add(new Wave(new ArrayList<>(Arrays.asList(0, 0, 0, 0, 1, 1, 1, 1, 2))));
    }

    // Método para obter a lista de ondas
    public ArrayList<Wave> getWaves() {
        return waves;
    }

    // Método para verificar se é hora de gerar um novo inimigo
    public boolean isTimeForNewEnemy() {
        return enemySpawnTick >= enemySpawnTickLimit;
    }

    // Método para verificar se há mais inimigos para gerar na onda atual
    public boolean isThereMoreEnemiesInWave() {
        return enemyIndex < waves.get(waveIndex).getEnemyList().size();
    }

    // Método para verificar se há mais ondas a serem processadas
    public boolean isThereMoreWaves() {
        return waveIndex + 1 < waves.size();
    }

    // Método para reiniciar o índice de inimigos para a onda atual
    public void resetEnemyIndex() {
        enemyIndex = 0;
    }

    // Método para obter o índice da onda atual
    public int getWaveIndex() {
        return waveIndex;
    }

    // Método para obter o tempo restante no temporizador da onda em segundos
    public float getTimeLeft() {
        float ticksLeft = waveTickLimit - waveTick;
        return ticksLeft / 60.0f;
    }

    // Método para verificar se o temporizador da onda foi iniciado
    public boolean isWaveTimerStarted() {
        return waveStartTimer;
    }

    // Método para reiniciar o WaveManager com novas ondas e reiniciar todos os contadores
    public void reset() {
        waves.clear();
        createWaves();
        enemyIndex = 0;
        waveIndex = 0;
        waveStartTimer = false;
        waveTickTimerOver = false;
        waveTick = 0;
        enemySpawnTick = enemySpawnTickLimit;
    }

}
